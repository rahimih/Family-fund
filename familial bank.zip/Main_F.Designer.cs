﻿namespace familial_bank
{
    partial class Main_f
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main_f));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.navBarControl1 = new DevExpress.XtraNavBar.NavBarControl();
            this.navBarGroup1 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem1 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem2 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem3 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem4 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem48 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem11 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem41 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem42 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem12 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem40 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem43 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem13 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup2 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem5 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem34 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem35 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem6 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem47 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem32 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem7 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup3 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem8 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem30 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem44 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem9 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem31 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem45 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem10 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem33 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem46 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup4 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem20 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem38 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem21 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem54 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem49 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem22 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem50 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem23 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem24 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem39 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem36 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem37 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup5 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem51 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem14 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem15 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem17 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem18 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem53 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem52 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem25 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem16 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem28 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem27 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem26 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem19 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem29 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem55 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem56 = new DevExpress.XtraNavBar.NavBarItem();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Enabled = false;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(601, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 28);
            this.label1.TabIndex = 4;
            this.label1.Text = "-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(64, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 19);
            this.label3.TabIndex = 23;
            this.label3.Text = "Exit";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // navBarControl1
            // 
            this.navBarControl1.ActiveGroup = this.navBarGroup1;
            this.navBarControl1.Appearance.GroupHeader.Font = new System.Drawing.Font("B Nazanin", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.navBarControl1.Appearance.GroupHeader.Options.UseFont = true;
            this.navBarControl1.Appearance.GroupHeaderActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.navBarControl1.Appearance.GroupHeaderActive.Font = new System.Drawing.Font("B Nazanin", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.navBarControl1.Appearance.GroupHeaderActive.Options.UseBackColor = true;
            this.navBarControl1.Appearance.GroupHeaderActive.Options.UseFont = true;
            this.navBarControl1.Appearance.Item.Font = new System.Drawing.Font("B Nazanin", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.navBarControl1.Appearance.Item.Options.UseFont = true;
            this.navBarControl1.Appearance.Item.Options.UseTextOptions = true;
            this.navBarControl1.Appearance.ItemActive.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.navBarControl1.Appearance.ItemActive.Font = new System.Drawing.Font("B Nazanin", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.navBarControl1.Appearance.ItemActive.Options.UseBackColor = true;
            this.navBarControl1.Appearance.ItemActive.Options.UseFont = true;
            this.navBarControl1.Dock = System.Windows.Forms.DockStyle.Right;
            this.navBarControl1.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.navBarGroup1,
            this.navBarGroup2,
            this.navBarGroup3,
            this.navBarGroup4,
            this.navBarGroup5});
            this.navBarControl1.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.navBarItem1,
            this.navBarItem2,
            this.navBarItem3,
            this.navBarItem4,
            this.navBarItem5,
            this.navBarItem6,
            this.navBarItem7,
            this.navBarItem8,
            this.navBarItem9,
            this.navBarItem10,
            this.navBarItem11,
            this.navBarItem12,
            this.navBarItem13,
            this.navBarItem14,
            this.navBarItem15,
            this.navBarItem16,
            this.navBarItem17,
            this.navBarItem18,
            this.navBarItem20,
            this.navBarItem21,
            this.navBarItem22,
            this.navBarItem23,
            this.navBarItem24,
            this.navBarItem25,
            this.navBarItem26,
            this.navBarItem27,
            this.navBarItem28,
            this.navBarItem30,
            this.navBarItem31,
            this.navBarItem32,
            this.navBarItem33,
            this.navBarItem34,
            this.navBarItem35,
            this.navBarItem36,
            this.navBarItem37,
            this.navBarItem38,
            this.navBarItem39,
            this.navBarItem40,
            this.navBarItem41,
            this.navBarItem42,
            this.navBarItem43,
            this.navBarItem44,
            this.navBarItem45,
            this.navBarItem46,
            this.navBarItem47,
            this.navBarItem48,
            this.navBarItem49,
            this.navBarItem50,
            this.navBarItem51,
            this.navBarItem19,
            this.navBarItem29,
            this.navBarItem52,
            this.navBarItem53,
            this.navBarItem54,
            this.navBarItem55,
            this.navBarItem56});
            this.navBarControl1.Location = new System.Drawing.Point(1036, 0);
            this.navBarControl1.Name = "navBarControl1";
            this.navBarControl1.OptionsNavPane.ExpandedWidth = 230;
            this.navBarControl1.PaintStyleKind = DevExpress.XtraNavBar.NavBarViewKind.NavigationPane;
            this.navBarControl1.Size = new System.Drawing.Size(230, 508);
            this.navBarControl1.TabIndex = 27;
            this.navBarControl1.Text = "navBarControl1";
            this.navBarControl1.View = new DevExpress.XtraNavBar.ViewInfo.StandardSkinNavigationPaneViewInfoRegistrator("Visual Studio 2013 Blue");
            this.navBarControl1.Click += new System.EventHandler(this.navBarControl1_Click);
            this.navBarControl1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.navBarControl1_KeyDown);
            // 
            // navBarGroup1
            // 
            this.navBarGroup1.Caption = "اعضا";
            this.navBarGroup1.Expanded = true;
            this.navBarGroup1.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem1),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem2),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem3),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem4),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem48),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem11),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem41),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem42),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem12),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem40),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem43),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem13)});
            this.navBarGroup1.Name = "navBarGroup1";
            // 
            // navBarItem1
            // 
            this.navBarItem1.Caption = "ثبت عضو جدید";
            this.navBarItem1.Name = "navBarItem1";
            this.navBarItem1.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem1_LinkClicked);
            // 
            // navBarItem2
            // 
            this.navBarItem2.Caption = "ویرایش اعضا";
            this.navBarItem2.Name = "navBarItem2";
            this.navBarItem2.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem2_LinkClicked);
            // 
            // navBarItem3
            // 
            this.navBarItem3.Caption = "فعال کردن اعضا";
            this.navBarItem3.Name = "navBarItem3";
            this.navBarItem3.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem3_LinkClicked);
            // 
            // navBarItem4
            // 
            this.navBarItem4.Caption = "تسویه حساب فرد";
            this.navBarItem4.Name = "navBarItem4";
            this.navBarItem4.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem4_LinkClicked);
            // 
            // navBarItem48
            // 
            this.navBarItem48.Caption = "تسویه وام اعضا";
            this.navBarItem48.Name = "navBarItem48";
            // 
            // navBarItem11
            // 
            this.navBarItem11.Caption = "دریافت حق عضویت فرد";
            this.navBarItem11.Name = "navBarItem11";
            this.navBarItem11.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem11_LinkClicked);
            // 
            // navBarItem41
            // 
            this.navBarItem41.Caption = "ویرایش مبالغ دریافتی حق عضویت افراد";
            this.navBarItem41.Name = "navBarItem41";
            this.navBarItem41.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem41_LinkClicked);
            // 
            // navBarItem42
            // 
            this.navBarItem42.Caption = "حذف مبالغ دریافتی حق عضویت افراد";
            this.navBarItem42.Name = "navBarItem42";
            this.navBarItem42.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem42_LinkClicked);
            // 
            // navBarItem12
            // 
            this.navBarItem12.Caption = "دریافت مبلغ ماهیانه فرد";
            this.navBarItem12.Name = "navBarItem12";
            this.navBarItem12.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem12_LinkClicked);
            // 
            // navBarItem40
            // 
            this.navBarItem40.Caption = "ویرایش مبالغ دریافتی ماهیانه افراد";
            this.navBarItem40.Name = "navBarItem40";
            this.navBarItem40.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem40_LinkClicked);
            // 
            // navBarItem43
            // 
            this.navBarItem43.Caption = "حذف مبالغ دریافتی ماهیانه افراد";
            this.navBarItem43.Name = "navBarItem43";
            this.navBarItem43.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem43_LinkClicked);
            // 
            // navBarItem13
            // 
            this.navBarItem13.Caption = "دریافت مبلغ ماهیانه افراد";
            this.navBarItem13.Name = "navBarItem13";
            this.navBarItem13.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem13_LinkClicked);
            // 
            // navBarGroup2
            // 
            this.navBarGroup2.Caption = "وام";
            this.navBarGroup2.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem5),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem34),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem35),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem6),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem47),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem32),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem7)});
            this.navBarGroup2.Name = "navBarGroup2";
            // 
            // navBarItem5
            // 
            this.navBarItem5.Caption = "پرداخت وام";
            this.navBarItem5.Name = "navBarItem5";
            this.navBarItem5.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem5_LinkClicked);
            // 
            // navBarItem34
            // 
            this.navBarItem34.Caption = "ویرایش وام پرداختی";
            this.navBarItem34.Name = "navBarItem34";
            this.navBarItem34.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem34_LinkClicked);
            // 
            // navBarItem35
            // 
            this.navBarItem35.Caption = "حذف وام پرداختی";
            this.navBarItem35.Name = "navBarItem35";
            this.navBarItem35.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem35_LinkClicked);
            // 
            // navBarItem6
            // 
            this.navBarItem6.Caption = "پرداخت اقساط اعضا";
            this.navBarItem6.Name = "navBarItem6";
            this.navBarItem6.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem6_LinkClicked);
            // 
            // navBarItem47
            // 
            this.navBarItem47.Caption = "مشاهده / ویرایش پرداخت اقساط";
            this.navBarItem47.Name = "navBarItem47";
            this.navBarItem47.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem47_LinkClicked);
            // 
            // navBarItem32
            // 
            this.navBarItem32.Caption = "دریافت اقساط ماهیانه افراد";
            this.navBarItem32.Name = "navBarItem32";
            this.navBarItem32.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem32_LinkClicked);
            // 
            // navBarItem7
            // 
            this.navBarItem7.Caption = "تسویه وام اعضا";
            this.navBarItem7.Name = "navBarItem7";
            this.navBarItem7.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem7_LinkClicked);
            // 
            // navBarGroup3
            // 
            this.navBarGroup3.Caption = "تعاریف";
            this.navBarGroup3.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem8),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem30),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem44),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem9),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem31),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem45),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem10),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem33),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem46)});
            this.navBarGroup3.Name = "navBarGroup3";
            // 
            // navBarItem8
            // 
            this.navBarItem8.Caption = "تعریف مبلغ حق عضویت سالیانه";
            this.navBarItem8.Name = "navBarItem8";
            this.navBarItem8.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem8_LinkClicked);
            // 
            // navBarItem30
            // 
            this.navBarItem30.Caption = "ویرایش مبلغ حق عضویت سالیانه";
            this.navBarItem30.Name = "navBarItem30";
            this.navBarItem30.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem30_LinkClicked);
            // 
            // navBarItem44
            // 
            this.navBarItem44.Caption = "حذف مبلغ حق عضویت سالیانه";
            this.navBarItem44.Name = "navBarItem44";
            this.navBarItem44.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem44_LinkClicked);
            // 
            // navBarItem9
            // 
            this.navBarItem9.Caption = "تعریف مبلغ پرداختی ماهیانه";
            this.navBarItem9.Name = "navBarItem9";
            this.navBarItem9.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem9_LinkClicked);
            // 
            // navBarItem31
            // 
            this.navBarItem31.Caption = "ویرایش مبلغ پرداختی ماهیانه";
            this.navBarItem31.Name = "navBarItem31";
            this.navBarItem31.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem31_LinkClicked);
            // 
            // navBarItem45
            // 
            this.navBarItem45.Caption = "حذف مبلغ پرداختی ماهیانه";
            this.navBarItem45.Name = "navBarItem45";
            this.navBarItem45.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem45_LinkClicked);
            // 
            // navBarItem10
            // 
            this.navBarItem10.Caption = "تعریف انواع وام";
            this.navBarItem10.Name = "navBarItem10";
            this.navBarItem10.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem10_LinkClicked);
            // 
            // navBarItem33
            // 
            this.navBarItem33.Caption = "ویرایش انواع وام";
            this.navBarItem33.Name = "navBarItem33";
            this.navBarItem33.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem33_LinkClicked);
            // 
            // navBarItem46
            // 
            this.navBarItem46.Caption = "غیر فعال کردن وام";
            this.navBarItem46.Name = "navBarItem46";
            this.navBarItem46.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem46_LinkClicked);
            // 
            // navBarGroup4
            // 
            this.navBarGroup4.Caption = "بانک";
            this.navBarGroup4.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem20),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem38),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem21),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem54),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem49),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem22),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem50),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem23),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem24),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem39),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem36),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem37)});
            this.navBarGroup4.Name = "navBarGroup4";
            // 
            // navBarItem20
            // 
            this.navBarItem20.Caption = "تعریف حسابهای بانکی";
            this.navBarItem20.Name = "navBarItem20";
            this.navBarItem20.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem20_LinkClicked);
            // 
            // navBarItem38
            // 
            this.navBarItem38.Caption = "مشاهده /ویرایش حسابهای بانکی";
            this.navBarItem38.Name = "navBarItem38";
            this.navBarItem38.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem38_LinkClicked);
            // 
            // navBarItem21
            // 
            this.navBarItem21.Caption = "واریز به حساب بانک";
            this.navBarItem21.Name = "navBarItem21";
            this.navBarItem21.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem21_LinkClicked);
            // 
            // navBarItem54
            // 
            this.navBarItem54.Caption = "واریز سود";
            this.navBarItem54.Name = "navBarItem54";
            this.navBarItem54.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem54_LinkClicked);
            // 
            // navBarItem49
            // 
            this.navBarItem49.Caption = "ویرایش فیش های واریزی";
            this.navBarItem49.Name = "navBarItem49";
            this.navBarItem49.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem49_LinkClicked);
            // 
            // navBarItem22
            // 
            this.navBarItem22.Caption = "برداشت از حساب بانک";
            this.navBarItem22.Name = "navBarItem22";
            this.navBarItem22.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem22_LinkClicked);
            // 
            // navBarItem50
            // 
            this.navBarItem50.Caption = "ویرایش فیش های برداشت از بانک";
            this.navBarItem50.Name = "navBarItem50";
            this.navBarItem50.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem50_LinkClicked);
            // 
            // navBarItem23
            // 
            this.navBarItem23.Caption = "مشخص نمودن امضا کنندگان حساب";
            this.navBarItem23.Name = "navBarItem23";
            this.navBarItem23.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem23_LinkClicked);
            // 
            // navBarItem24
            // 
            this.navBarItem24.Caption = "ثبت دسته چک ";
            this.navBarItem24.Name = "navBarItem24";
            this.navBarItem24.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem24_LinkClicked);
            // 
            // navBarItem39
            // 
            this.navBarItem39.Caption = "مشاهده /ویرایش دسته چک";
            this.navBarItem39.Name = "navBarItem39";
            this.navBarItem39.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem39_LinkClicked);
            // 
            // navBarItem36
            // 
            this.navBarItem36.Caption = " موجودی حسابهای بانکی";
            this.navBarItem36.Name = "navBarItem36";
            this.navBarItem36.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem36_LinkClicked);
            // 
            // navBarItem37
            // 
            this.navBarItem37.Caption = " ریز کارکرد حساب";
            this.navBarItem37.Name = "navBarItem37";
            this.navBarItem37.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem37_LinkClicked);
            // 
            // navBarGroup5
            // 
            this.navBarGroup5.Caption = "گزارشات";
            this.navBarGroup5.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem51),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem14),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem15),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem17),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem18),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem53),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem52),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem25),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem16),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem28),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem27),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem26),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem19),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem29),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem55),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBarItem56)});
            this.navBarGroup5.Name = "navBarGroup5";
            this.navBarGroup5.TopVisibleLinkIndex = 1;
            // 
            // navBarItem51
            // 
            this.navBarItem51.Caption = "گزارش صندوق";
            this.navBarItem51.Name = "navBarItem51";
            this.navBarItem51.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem51_LinkClicked);
            // 
            // navBarItem14
            // 
            this.navBarItem14.Caption = "مشاهده ریز پرداختی ماهیانه فرد";
            this.navBarItem14.Name = "navBarItem14";
            this.navBarItem14.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem14_LinkClicked);
            // 
            // navBarItem15
            // 
            this.navBarItem15.Caption = "مشاهده وام های پرداختی به فرد";
            this.navBarItem15.Name = "navBarItem15";
            this.navBarItem15.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem15_LinkClicked);
            // 
            // navBarItem17
            // 
            this.navBarItem17.Caption = "مشاهده مبلغ کل واریزی  به تفکیک اعضا";
            this.navBarItem17.Name = "navBarItem17";
            this.navBarItem17.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem17_LinkClicked);
            // 
            // navBarItem18
            // 
            this.navBarItem18.Caption = "مشاهده مبلغ واریزی ماهیانه به تفکیک ماه";
            this.navBarItem18.Name = "navBarItem18";
            this.navBarItem18.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem18_LinkClicked);
            // 
            // navBarItem53
            // 
            this.navBarItem53.Caption = "مشاهده مبلغ کل اقساط  به تفکیک اعضا";
            this.navBarItem53.Name = "navBarItem53";
            this.navBarItem53.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem53_LinkClicked);
            // 
            // navBarItem52
            // 
            this.navBarItem52.Caption = "مشاهده مبلغ واریزی اقساط به تفکیک ماه";
            this.navBarItem52.Name = "navBarItem52";
            this.navBarItem52.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem52_LinkClicked);
            // 
            // navBarItem25
            // 
            this.navBarItem25.Caption = "مشاهده وام های تسویه شده";
            this.navBarItem25.Name = "navBarItem25";
            this.navBarItem25.Visible = false;
            // 
            // navBarItem16
            // 
            this.navBarItem16.Caption = "مشاهده وضعیت اقساط پرداختی اعضا";
            this.navBarItem16.Name = "navBarItem16";
            this.navBarItem16.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem16_LinkClicked);
            // 
            // navBarItem28
            // 
            this.navBarItem28.Caption = "مشاهده مبلغ کل کارمزد دریافتی";
            this.navBarItem28.Name = "navBarItem28";
            this.navBarItem28.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem28_LinkClicked);
            // 
            // navBarItem27
            // 
            this.navBarItem27.Caption = "چاپ دفترچه دریافتی ماهیانه";
            this.navBarItem27.Name = "navBarItem27";
            this.navBarItem27.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem27_LinkClicked);
            // 
            // navBarItem26
            // 
            this.navBarItem26.Caption = "چاپ دفترچه اقساط";
            this.navBarItem26.Name = "navBarItem26";
            this.navBarItem26.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem26_LinkClicked);
            // 
            // navBarItem19
            // 
            this.navBarItem19.Caption = "مغایرت گیری ماهیانه";
            this.navBarItem19.Name = "navBarItem19";
            this.navBarItem19.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem19_LinkClicked_1);
            // 
            // navBarItem29
            // 
            this.navBarItem29.Caption = "مغایرت گیری وام";
            this.navBarItem29.Name = "navBarItem29";
            this.navBarItem29.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem29_LinkClicked_1);
            // 
            // navBarItem55
            // 
            this.navBarItem55.Caption = "پشتیبان گیری";
            this.navBarItem55.Name = "navBarItem55";
            this.navBarItem55.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem55_LinkClicked);
            // 
            // navBarItem56
            // 
            this.navBarItem56.Caption = "بازیابی اطلاعات";
            this.navBarItem56.Enabled = false;
            this.navBarItem56.Hint = "F8 & F9";
            this.navBarItem56.Name = "navBarItem56";
            this.navBarItem56.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBarItem56_LinkClicked);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("B Nazanin", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(499, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(274, 38);
            this.label2.TabIndex = 28;
            this.label2.Text = "صندوق قرض الحسنه خانوادگی ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("B Nazanin", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(573, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 38);
            this.label4.TabIndex = 29;
            this.label4.Text = "امام علی (ع)";
            // 
            // Main_f
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1266, 508);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.navBarControl1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Main_f";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "نرم افزار صندوق قرض الحسنه خانوادگی";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Main_f_FormClosed);
            this.Load += new System.EventHandler(this.Main_f_Load);
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private DevExpress.XtraNavBar.NavBarControl navBarControl1;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup1;
        private DevExpress.XtraNavBar.NavBarItem navBarItem1;
        private DevExpress.XtraNavBar.NavBarItem navBarItem2;
        private DevExpress.XtraNavBar.NavBarItem navBarItem3;
        private DevExpress.XtraNavBar.NavBarItem navBarItem4;
        private DevExpress.XtraNavBar.NavBarItem navBarItem11;
        private DevExpress.XtraNavBar.NavBarItem navBarItem12;
        private DevExpress.XtraNavBar.NavBarItem navBarItem13;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup2;
        private DevExpress.XtraNavBar.NavBarItem navBarItem5;
        private DevExpress.XtraNavBar.NavBarItem navBarItem34;
        private DevExpress.XtraNavBar.NavBarItem navBarItem35;
        private DevExpress.XtraNavBar.NavBarItem navBarItem6;
        private DevExpress.XtraNavBar.NavBarItem navBarItem32;
        private DevExpress.XtraNavBar.NavBarItem navBarItem7;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup3;
        private DevExpress.XtraNavBar.NavBarItem navBarItem8;
        private DevExpress.XtraNavBar.NavBarItem navBarItem30;
        private DevExpress.XtraNavBar.NavBarItem navBarItem9;
        private DevExpress.XtraNavBar.NavBarItem navBarItem31;
        private DevExpress.XtraNavBar.NavBarItem navBarItem10;
        private DevExpress.XtraNavBar.NavBarItem navBarItem33;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup4;
        private DevExpress.XtraNavBar.NavBarItem navBarItem20;
        private DevExpress.XtraNavBar.NavBarItem navBarItem21;
        private DevExpress.XtraNavBar.NavBarItem navBarItem22;
        private DevExpress.XtraNavBar.NavBarItem navBarItem23;
        private DevExpress.XtraNavBar.NavBarItem navBarItem24;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup5;
        private DevExpress.XtraNavBar.NavBarItem navBarItem14;
        private DevExpress.XtraNavBar.NavBarItem navBarItem15;
        private DevExpress.XtraNavBar.NavBarItem navBarItem16;
        private DevExpress.XtraNavBar.NavBarItem navBarItem17;
        private DevExpress.XtraNavBar.NavBarItem navBarItem18;
        private DevExpress.XtraNavBar.NavBarItem navBarItem25;
        private DevExpress.XtraNavBar.NavBarItem navBarItem28;
        private DevExpress.XtraNavBar.NavBarItem navBarItem27;
        private DevExpress.XtraNavBar.NavBarItem navBarItem26;
        private DevExpress.XtraNavBar.NavBarItem navBarItem36;
        private DevExpress.XtraNavBar.NavBarItem navBarItem37;
        private DevExpress.XtraNavBar.NavBarItem navBarItem38;
        private DevExpress.XtraNavBar.NavBarItem navBarItem39;
        private DevExpress.XtraNavBar.NavBarItem navBarItem41;
        private DevExpress.XtraNavBar.NavBarItem navBarItem40;
        private DevExpress.XtraNavBar.NavBarItem navBarItem42;
        private DevExpress.XtraNavBar.NavBarItem navBarItem43;
        private DevExpress.XtraNavBar.NavBarItem navBarItem44;
        private DevExpress.XtraNavBar.NavBarItem navBarItem45;
        private DevExpress.XtraNavBar.NavBarItem navBarItem46;
        private DevExpress.XtraNavBar.NavBarItem navBarItem47;
        private DevExpress.XtraNavBar.NavBarItem navBarItem48;
        private DevExpress.XtraNavBar.NavBarItem navBarItem49;
        private DevExpress.XtraNavBar.NavBarItem navBarItem50;
        private DevExpress.XtraNavBar.NavBarItem navBarItem51;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label label4;
        private DevExpress.XtraNavBar.NavBarItem navBarItem19;
        private DevExpress.XtraNavBar.NavBarItem navBarItem29;
        private DevExpress.XtraNavBar.NavBarItem navBarItem52;
        private DevExpress.XtraNavBar.NavBarItem navBarItem53;
        private DevExpress.XtraNavBar.NavBarItem navBarItem54;
        private DevExpress.XtraNavBar.NavBarItem navBarItem55;
        private DevExpress.XtraNavBar.NavBarItem navBarItem56;

        
       
    }
}



